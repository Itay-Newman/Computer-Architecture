int mystery(int a, int b, int c)
{
    return a * a - (b << 2) * c;
}